# A starter project for Aleut.css

~~~ssh
# Download all the project dependencies with npm
$ npm i
# Use the built-in compiler (or just bring your own)
$ npm start
~~~

If you want to make one-off build without watching and recompiling, 
there's `npm run build` script which compiles `style.sass` to `./css` directory.

[Read the full documentation](http://aleutcss.github.io/)
